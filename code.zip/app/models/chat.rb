class Chat < ApplicationRecord
end
