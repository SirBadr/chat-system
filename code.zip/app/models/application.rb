class Application < ApplicationRecord
    validates :name, presence: true
end
