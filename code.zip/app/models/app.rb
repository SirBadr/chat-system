class App < ApplicationRecord
    validates :name, presence: true
end
